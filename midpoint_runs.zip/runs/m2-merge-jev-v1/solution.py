def merge_intervals(intervals):
    ordered = []
    for start, end in intervals:
        if start > end:
            raise ValueError("interval start must not exceed end")
        ordered.append((start, end))
    ordered.sort()
    result = []
    for start, end in ordered:
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    return result
