def merge_intervals(intervals):
    ordered = []
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not exceed its end")
        ordered.append((start, end))
    ordered.sort(key=lambda interval: interval[0])
    result = []
    for start, end in ordered:
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    return result
