def merge_intervals(intervals):
    if not intervals:
        return []
    
    processed = []
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError("reversed interval")
        processed.append((start, end))
    
    processed.sort()
    result = [processed[0]]
    
    for start, end in processed[1:]:
        if start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    
    return result
